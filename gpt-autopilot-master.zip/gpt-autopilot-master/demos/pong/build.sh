#!/bin/bash

gcc -o pong pong.c -lraylib -lGL -lm -lpthread -ldl -lrt -lX11
