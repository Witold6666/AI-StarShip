# Test: JS Inventory System

Expected result is a web application that can be run directly by opening `index.html`. There will be a form for adding products with name, price and quantity to the inventory. The products will be listed in a form and each product will have a delete button. Products will persist over page reloads in LocalStorage. There will be a search function for filtering out the product list.

