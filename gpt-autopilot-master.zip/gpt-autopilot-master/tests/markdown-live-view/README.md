# Test: Markdown Live View

The expected result is a website that has a text area on the left side where you can input some Markdown and on the right you will see a live preview of the formatted text as you type.
