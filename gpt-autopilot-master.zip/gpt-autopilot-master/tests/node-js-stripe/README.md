# Test: Node.js Stripe Payment Form

The expected result is a form that asks for a name, email address and special requests and a Stripe credit card input form.

This has not been tested with an actual Stripe API key, but it does load the payment form from Stripe.
